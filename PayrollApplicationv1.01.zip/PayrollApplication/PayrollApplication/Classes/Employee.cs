﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PayrollApplication.Classes
{
    public class Employee
    {
        public int _empID;
        public string _fName, _lName;
        public static string _ssn;
        public DateTime _doH;
        public string _address, _city, _state, _zip, _email, _phone;
        public decimal _payRate;

        public Employee(int empID, string fName, string lName, string ssn, DateTime doH, string address, string city, string state, 
                        string zip, string email, string phone, decimal payRate)
        {
            _empID = empID;
            _fName = fName;
            _lName = lName;
            _ssn = ssn;
            _doH = doH;
            _address = address;
            _city = city;
            _state = state;
            _zip = zip;
            _email = email;
            _phone = phone;
            _payRate = payRate;
        }
        public Employee() { }
    }
}

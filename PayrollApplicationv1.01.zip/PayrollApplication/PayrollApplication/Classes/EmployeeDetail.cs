﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PayrollApplication.Classes
{
    public class EmployeeDetail
    {
        public string _fName;
        public string _lName;
        public decimal _pTO;
        public decimal _medInsDeduction, _dentInsDeduction;

        public EmployeeDetail(string fName, string lName, decimal pTO, decimal medInsDeduction, decimal dentInsDeduction)
        {
            _fName = fName;
            _lName = lName;
            _pTO = pTO;
            _medInsDeduction = medInsDeduction;
            _dentInsDeduction = dentInsDeduction;
        }
        public EmployeeDetail() { }
    }
}

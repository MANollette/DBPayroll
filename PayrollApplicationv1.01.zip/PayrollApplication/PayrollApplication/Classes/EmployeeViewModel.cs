﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PayrollApplication.Classes
{
    public class EmployeeViewModel
    {
        public int ID { get; set; }
        public string Name { get; set; }
        public string Address { get; set; }
        public string HireDate { get; set; }
        public string Phone { get; set; }
        public decimal PayRate { get; set; }
        public string Email { get; set; }

        
    }


}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PayrollApplication.Classes
{
    public class Shift
    {
        public int _empID;
        public string _fName;
        public string _lName;
        public DateTime _date;
        public string _shiftStart;
        public string _shiftEnd;
        public decimal _hoursWorked;

        public Shift(int empID, string fName, string lName, DateTime date, string shiftStart, string shiftEnd, decimal hoursWorked)
        {
            _empID = empID;
            _fName = fName;
            _lName = lName;
            _date = date;
            _shiftStart = shiftStart;
            _shiftEnd = shiftEnd;
            _hoursWorked = hoursWorked;
        }

        public Shift() { }
    }
}

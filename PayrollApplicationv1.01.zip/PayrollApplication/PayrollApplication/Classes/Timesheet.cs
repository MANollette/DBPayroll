﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PayrollApplication.Classes
{
    public class Timesheet
    {
        public int _empID { get; set; }
        public int _checkNumber { get; set; }
        public string _fName { get; set; }
        public string _lName { get; set; }
        public string _shiftType { get; set; }
        public DateTime _startDate { get; set; }
        public DateTime _endDate { get; set; }
        public decimal _payRate { get; set; }
        public decimal _totalHours { get; set; }
        public decimal _otHours { get; set; }
        public decimal _medInsDeduction { get; set; }
        public decimal _dentalDeduction { get; set; }
        public decimal _netPay { get; set; }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using PayrollApplication.Classes;
using System.Data.SqlClient;
using iTextSharp.text;
using iTextSharp.text.pdf;
using System.IO;

namespace PayrollApplication.Windows
{
    /// <summary>
    /// Interaction logic for TimesheetBrowse.xaml
    /// </summary>
    public partial class TimesheetBrowse : Window
    {

        MidTier mt = new MidTier();

        public TimesheetBrowse()
        {
            InitializeComponent();
            this.Timesheets = new ObservableCollection<TimesheetViewModel>();
            this.DataContext = this;
        }

        //Collection creation for data binding
        public ObservableCollection<TimesheetViewModel> Timesheets { get; private set; }

        //Button events
        #region buttons

        private void btnExportCheckToPdf_Click(object sender, RoutedEventArgs e)
        {
            int index = lvwTSSearch.SelectedIndex;
            List<Timesheet> tslist = GetTimesheets();
            if (index != -1)
            {
                Timesheet ts = tslist[index];
                ExportToPdf(ts);
            }
            else MessageBox.Show("Please select a timesheet.");
        }

        private void btnMainMenu_Click(object sender, RoutedEventArgs e)
        {
            dbMenu dbm = new dbMenu();
            dbm.Show();
            this.Close();
        }

        private void btnSearchTSByName_Click(object sender, RoutedEventArgs e)
        {
            Timesheets.Clear();
            string fName = txtSearchTSFName.Text;
            string lName = txtSearchTSLName.Text;
            List<Timesheet> tsList = GetTimesheetsByName(fName, lName);
            foreach (Timesheet ts in tsList)
            {
                var model = new TimesheetViewModel
                {
                    ID = ts._empID,
                    CheckNumber = ts._checkNumber,
                    Name = ts._fName + " " + ts._lName,
                    DateRange = ts._startDate.ToShortDateString() + " to " + ts._endDate.ToShortDateString(),
                    Hours = ts._totalHours,
                    DentalDeduction = ts._dentalDeduction,
                    MedDeduction = ts._medInsDeduction,
                    OTHours = ts._otHours,
                    PayRate = ts._payRate,
                    NetPay = ts._netPay
                };
                Timesheets.Add(model);
            }
        }

        private void btnSearchTSByAll_Click(object sender, RoutedEventArgs e)
        {
            GetTimesheetView();
        }

        private void btnDeleteSelectedCheck_click(object sender, RoutedEventArgs e)
        {
            try
            {
                int index = lvwTSSearch.SelectedIndex;
                List<Timesheet> tsList = GetTimesheets();
                Timesheet ts = tsList[index];
                int check = ts._checkNumber;
                int x = mt.DeleteTimesheet(check);
                if (x == 1) MessageBox.Show("Timesheet deleted.");
                else if (x == 0) MessageBox.Show("Timesheet not found.");
                else if (x >= 2) MessageBox.Show("Something went wrong. \nRows updated: " + x);
                GetTimesheetView();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        #endregion

        //Methods for retrieving data
        #region Get Methods
        private void GetTimesheetView()
        {
            Timesheets.Clear();
            List<Timesheet> tsList = GetTimesheets();
            foreach (Timesheet ts in tsList)
            {
                var model = new TimesheetViewModel
                {
                    ID = ts._empID,
                    CheckNumber = ts._checkNumber,
                    Name = ts._fName + " " + ts._lName,
                    DateRange = ts._startDate.ToShortDateString() + " to " + ts._endDate.ToShortDateString(),
                    Hours = ts._totalHours,
                    DentalDeduction = ts._dentalDeduction,
                    MedDeduction = ts._medInsDeduction,
                    OTHours = ts._otHours,
                    PayRate = ts._payRate,
                    NetPay = ts._netPay
                };
                Timesheets.Add(model);
            }
        }

        public List<Timesheet> GetTimesheets()
        {
            List<Timesheet> tsList = new List<Timesheet>();
            SqlDataReader sdrTs = mt.GetTimesheet();
            if (sdrTs.HasRows)
            {
                while (sdrTs.Read())
                {
                    //e.EmpID FName, LName, StartDate, EndDate, PayRate, TotalHours, OTHours, MedInsDeduction, DentInsDeduction, NetPay
                    Timesheet ts = new Timesheet();
                    if (sdrTs["EmpID"] != null)
                        ts._empID = int.Parse(sdrTs["EmpID"].ToString());
                    if (sdrTs["CheckNumber"] != null)
                        ts._checkNumber = int.Parse(sdrTs["CheckNumber"].ToString());
                    if (sdrTs["FName"] != null)
                        ts._fName = sdrTs["FName"].ToString();
                    if (sdrTs["LName"] != null)
                        ts._lName = sdrTs["LName"].ToString();
                    if (sdrTs["StartDate"] != null)
                        ts._startDate = (DateTime)sdrTs["StartDate"];
                    if (sdrTs["EndDate"] != null)
                        ts._endDate = (DateTime)sdrTs["EndDate"];
                    if (sdrTs["PayRate"] != null)
                    {
                        decimal payrate = decimal.Parse(sdrTs["PayRate"].ToString());
                        ts._payRate = Math.Round(payrate, 2);
                    }
                    if (sdrTs["TotalHours"] != null)
                        ts._totalHours = decimal.Parse(sdrTs["TotalHours"].ToString());
                    if (sdrTs["OTHours"] != null)
                        ts._otHours = decimal.Parse(sdrTs["OTHours"].ToString());
                    if (sdrTs["MedInsDeduction"] != null)
                    {
                        decimal med = decimal.Parse(sdrTs["MedInsDeduction"].ToString());
                        ts._medInsDeduction = Math.Round(med, 2);
                    }
                    if (sdrTs["DentInsDeduction"] != null)
                    {
                        decimal dent = decimal.Parse(sdrTs["DentInsDeduction"].ToString());
                        ts._dentalDeduction = Math.Round(dent, 2);
                    }
                    if (sdrTs["NetPay"] != null)
                    {
                        decimal netpay = decimal.Parse(sdrTs["NetPay"].ToString());
                        ts._netPay = Math.Round(netpay, 2);
                    }
                    tsList.Add(ts);
                }
            }
            sdrTs.Close();
            return tsList;
        }

        public List<Timesheet> GetTimesheetsByName(string fName, string lName)
        {
            List<Timesheet> tsList = new List<Timesheet>();
            SqlDataReader sdrTs = mt.GetTimesheet();
            if (sdrTs.HasRows)
            {
                while (sdrTs.Read())
                {
                    //e.EmpID FName, LName, StartDate, EndDate, PayRate, TotalHours, OTHours, MedInsDeduction, DentInsDeduction, NetPay
                    Timesheet ts = new Timesheet();
                    if (sdrTs["EmpID"] != null)
                        ts._empID = int.Parse(sdrTs["EmpID"].ToString());
                    if (sdrTs["FName"] != null)
                        ts._fName = sdrTs["FName"].ToString();
                    if (sdrTs["LName"] != null)
                        ts._lName = sdrTs["LName"].ToString();
                    if (sdrTs["StartDate"] != null)
                        ts._startDate = (DateTime)sdrTs["StartDate"];
                    if (sdrTs["EndDate"] != null)
                        ts._endDate = (DateTime)sdrTs["EndDate"];
                    if (sdrTs["PayRate"] != null)
                        ts._payRate = decimal.Parse(sdrTs["PayRate"].ToString());
                    if (sdrTs["TotalHours"] != null)
                        ts._totalHours = decimal.Parse(sdrTs["TotalHours"].ToString());
                    if (sdrTs["OTHours"] != null)
                        ts._otHours = decimal.Parse(sdrTs["OTHours"].ToString());
                    if (sdrTs["MedInsDeduction"] != null)
                        ts._medInsDeduction = decimal.Parse(sdrTs["MedInsDeduction"].ToString());
                    if (sdrTs["DentInsDeduction"] != null)
                        ts._dentalDeduction = decimal.Parse(sdrTs["DentInsDeduction"].ToString());
                    if (sdrTs["NetPay"] != null)
                        ts._netPay = decimal.Parse(sdrTs["NetPay"].ToString());
                    if (ts._fName == fName && ts._lName == lName)
                        tsList.Add(ts);
                }
            }
            sdrTs.Close();
            return tsList;
        }
        #endregion

        public void ExportToPdf(Timesheet ts)
        {
            Document document = new Document();
            document.SetPageSize(iTextSharp.text.PageSize.A4.Rotate());
            PdfWriter writer = PdfWriter.GetInstance(document, new FileStream("C:\\Users\\Public\\Downloads\\" + ts._lName + "_" + ts._checkNumber.ToString() + ".pdf", FileMode.Create, FileAccess.ReadWrite));
            document.Open();
            iTextSharp.text.Font font4 = iTextSharp.text.FontFactory.GetFont(FontFactory.HELVETICA, 8);
            iTextSharp.text.Font font5 = iTextSharp.text.FontFactory.GetFont(FontFactory.HELVETICA, 10);

            PdfPTable table = new PdfPTable(12);
            int[] intTblWidth = { 10, 20, 20, 12, 24, 24, 16, 16, 16, 16, 16, 16 };
            table.SetWidths(intTblWidth);

            string[] tsProp = new string[] {ts._empID.ToString(), ts._fName, ts._lName, ts._checkNumber.ToString(), ts._startDate.ToShortDateString(), ts._endDate.ToShortDateString(),
                                          ts._payRate.ToString(), ts._otHours.ToString(), ts._medInsDeduction.ToString(), ts._dentalDeduction.ToString(), (ts._netPay * (decimal).2).ToString(), ts._netPay.ToString()};
            string[] tsPropColName = new string[] {"ID", "First Name", "Last Name", "Check Number", "Start Date", "End Date",
                                                    "Pay Rate", "OT Hours", "Medical Deduction", "Dental Deduction", "Tax Deduction", "Net Pay"};
            PdfPCell[] cells = new PdfPCell[] {
                                    new PdfPCell(new Phrase(tsPropColName[0], font5)),
                                    new PdfPCell(new Phrase(tsPropColName[1], font5)),
                                    new PdfPCell(new Phrase(tsPropColName[2], font5)),
                                    new PdfPCell(new Phrase(tsPropColName[3], font5)),
                                    new PdfPCell(new Phrase(tsPropColName[4], font5)),
                                    new PdfPCell(new Phrase(tsPropColName[5], font5)),
                                    new PdfPCell(new Phrase(tsPropColName[6], font5)),
                                    new PdfPCell(new Phrase(tsPropColName[7], font5)),
                                    new PdfPCell(new Phrase(tsPropColName[8], font4)),
                                    new PdfPCell(new Phrase(tsPropColName[9], font4)),
                                    new PdfPCell(new Phrase(tsPropColName[10], font4)),
                                    new PdfPCell(new Phrase(tsPropColName[11], font5))};          
            PdfPRow row = new PdfPRow(cells);
            table.Rows.Add(row);
            cells = new PdfPCell[] {
                                    new PdfPCell(new Phrase(tsProp[0], font5)),
                                    new PdfPCell(new Phrase(tsProp[1], font5)),
                                    new PdfPCell(new Phrase(tsProp[2], font5)),
                                    new PdfPCell(new Phrase(tsProp[3], font5)),
                                    new PdfPCell(new Phrase(tsProp[4], font5)),
                                    new PdfPCell(new Phrase(tsProp[5], font5)),
                                    new PdfPCell(new Phrase(tsProp[6], font5)),
                                    new PdfPCell(new Phrase(tsProp[7], font5)),
                                    new PdfPCell(new Phrase(tsProp[8], font5)),
                                    new PdfPCell(new Phrase(tsProp[9], font5)),
                                    new PdfPCell(new Phrase(tsProp[10], font5)),
                                    new PdfPCell(new Phrase(tsProp[11], font5))};
            row = new PdfPRow(cells);
            table.Rows.Add(row);
            document.Add(table);

            //PdfPTable table = new PdfPTable(13);
            //float[] widths = new float[] { 4f, 4f, 4f, 4f };


            //table.WidthPercentage = 100;
            //PdfPCell cell = new PdfPCell(new Phrase("Payroll"));

            //cell.Colspan = 13;

            //for(int i = 0; i < tsProp.Count(); i++)
            //{

            //    table.AddCell(new Phrase(tsPropColName[i], font5));
            //}
            //PdfPRow row = new PdfPRow(cell);
            //table.Rows.Add(row);
            //foreach (string s in tsProp)
            //{
            //    table.AddCell(new Phrase(s, font5));          
            //}
            //document.Add(table);
            document.Close();
        }

        
    }
}

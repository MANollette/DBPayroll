﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Text.RegularExpressions;
using System.Runtime.Serialization;
using System.Data.SqlClient;

namespace PayrollApplication.Windows
{
    /// <summary>
    /// Interaction logic for NewShiftForm.xaml
    /// </summary>
    public partial class NewShiftForm : Window
    {

        MidTier mt = new MidTier();

        public NewShiftForm()
        {
            InitializeComponent();
            datSDate.SelectedDate = DateTime.Today;
        }

        #region buttons
        private void btnMainMenu_Click(object sender, RoutedEventArgs e)
        {
            dbMenu dbm = new dbMenu();
            dbm.Show();
            this.Close();
        }

        private void btnAddShift_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                //Variables for insertion
                string fName = txtSFName.Text;
                string lName = txtSLName.Text;
                DateTime date = (DateTime)datSDate.SelectedDate;
                string startTime = txtSShiftStart.Text.Insert(2, ":");
                string endTime = txtSShiftEnd.Text.Insert(2, ":");
                TimeSpan duration = new TimeSpan();
                if (int.Parse(txtSShiftStart.Text) < int.Parse(txtSShiftEnd.Text))
                {
                    duration = DateTime.Parse(startTime).Subtract(DateTime.Parse(endTime));
                }
                else
                {
                    DateTime endDate = DateTime.Parse(endTime).AddDays(1);
                    duration = DateTime.Parse(startTime).Subtract(endDate);
                }
                decimal hoursWorked = decimal.Parse(duration.ToString().Substring(1, 2));


                int countCheck1 = mt.ShiftCount();
                int insertShift = mt.InsertNewShift(lName, fName, date, startTime, endTime, hoursWorked);
                int countCheck2 = mt.ShiftCount();
                if (countCheck1 < countCheck2) MessageBox.Show("Shift Successfully Inserted");
                else MessageBox.Show("Employee not found.");
            }
            catch(Exception exc)
            {
                MessageBox.Show(exc.Message);
            }         
        }
#endregion

        #region textboxPreviewHandling
        private void txtSShiftStart_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            e.Handled = !IsTextAllowed(e.Text);
        }

        private void txtSHoursWorked_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            e.Handled = !IsTextAllowed(e.Text);
        }

        private void txtSShiftEnd_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            e.Handled = !IsTextAllowed(e.Text);
        }
        #endregion

        #region textboxFormatting

        //Method for handling non-numeric text input. 
        private static bool IsTextAllowed(string text)
        {
            Regex regex = new Regex("[^0-9]"); //regex that matches disallowed text
            return !regex.IsMatch(text);
        }

        private void TextBox_PreviewExecuted(object sender, ExecutedRoutedEventArgs e)
        {
            if (e.Command == ApplicationCommands.Paste) e.Handled = true;
        }

        #endregion

        #region getLists
        public int GetShiftCount()
        {
            int shiftCount = mt.ShiftCount();
            return shiftCount;
        }
#endregion


    }
}

﻿using PayrollApplication.Classes;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace PayrollApplication.Windows
{
    /// <summary>
    /// Interaction logic for NewTimesheetForm.xaml
    /// </summary>
    public partial class NewTimesheetForm : Window
    {
        public NewTimesheetForm()
        {
            InitializeComponent();
            datTSEndDate.SelectedDate = DateTime.Now;
            datTSStartDate.SelectedDate = DateTime.Now;
        }

        MidTier mt = new MidTier();

        #region buttons
        private void btnMainMenu_Click(object sender, RoutedEventArgs e)
        {
            dbMenu dbm = new dbMenu();
            dbm.Show();
            this.Close();
        }

        private void btnAddTimeSheet_Click(object sender, RoutedEventArgs e)
        {
            string fName = txtTSFName.Text;
            string lName = txtTSLName.Text;
            string shiftsType = "";
            if (cboTSShiftType.SelectedIndex == 0) shiftsType = "WS";
            else if (cboTSShiftType.SelectedIndex == 1) shiftsType = "TO";
            DateTime startDate = (DateTime)datTSStartDate.SelectedDate;
            DateTime endDate = (DateTime)datTSEndDate.SelectedDate;
            decimal oTHours = 0;
            decimal deductions = GetDeductions(fName, lName);
            //Calculation to get days since last Sunday
            int dayCheck = 1000;
            for(int i = 0; i<7; i++)
            {
                if ((startDate.DayOfWeek - i).ToString() == "Sunday")
                    dayCheck = i;
            }

            //loop to check through each week in shift range.
            DateTime dtCheck = startDate;
            decimal totalHours = 0;
            while (dtCheck < endDate)
            {                
                List<Shift> tsl = GetShiftsByDate(dtCheck.AddDays(-dayCheck), dtCheck.AddDays(-dayCheck + 7));
                decimal hourCheck = 0;
                foreach (Shift s in tsl)
                {
                    hourCheck += s._hoursWorked;
                    if (s._date < endDate) totalHours += s._hoursWorked;
                }
                if (hourCheck > 40)
                    oTHours += (hourCheck - 40);
                dtCheck = dtCheck.AddDays(7);
            }


            //TO DO: Try to retrieve income tax rate from government website
            decimal taxRate = (decimal)0.20;



            int insertTimesheet = mt.InsertNewTimesheet(lName, fName, shiftsType, startDate, endDate, oTHours, taxRate, deductions);
            if (insertTimesheet == 1) MessageBox.Show("Timesheet inserted.");
            else if (insertTimesheet == 0) MessageBox.Show("Employee not found");
            else MessageBox.Show("Something went wrong. Updated rows: " + insertTimesheet.ToString());

            decimal pto = GetPTO(fName, lName);
            pto = pto + (totalHours * (decimal).025);
            int updatePTO = mt.UpdatePTO(fName, lName, pto);

        }

        private void btnAddDateRangeTimeSheets_Click(object sender, RoutedEventArgs e)
        {

        }
#endregion

        #region getLists

        //Gets deductions from medical and dental insurance
        public decimal GetDeductions(string fName, string lName)
        {
            decimal deductions = 0;
            try
            {
                List<EmployeeDetail> empList = new List<EmployeeDetail>();
                SqlDataReader sdrDed = mt.GetDeductions();
                if (sdrDed.HasRows)
                {
                    while (sdrDed.Read())
                    {
                        EmployeeDetail ed = new EmployeeDetail();
                        if (sdrDed["FName"] != null)
                            ed._fName = sdrDed["FName"].ToString();
                        if (sdrDed["LName"] != null)
                            ed._lName = sdrDed["LName"].ToString();
                        if (sdrDed["MedInsDeduction"] != null)
                            ed._medInsDeduction = decimal.Parse(sdrDed["MedInsDeduction"].ToString());
                        if (sdrDed["DentInsDeduction"] != null)
                            ed._dentInsDeduction = decimal.Parse(sdrDed["DentInsDeduction"].ToString());
                        ed._pTO = 0;
                        empList.Add(ed);
                    }
                }

                foreach(EmployeeDetail ed in empList)
                {
                    if (ed._fName == fName && ed._lName == lName)
                    {
                        deductions += (ed._medInsDeduction + ed._dentInsDeduction);
                    }
                }
                sdrDed.Close();
                return deductions;
            }
            catch(Exception exc)
            {
                MessageBox.Show(exc.Message);
            }
            return deductions;
        }

        //Gets current PTO hours
        public decimal GetPTO(string fName, string lName)
        {
            decimal pto = 0;
            try
            {
                List<EmployeeDetail> empList = new List<EmployeeDetail>();
                SqlDataReader sdrDed = mt.GetPTO();
                if (sdrDed.HasRows)
                {
                    while (sdrDed.Read())
                    {
                        EmployeeDetail ed = new EmployeeDetail();
                        if (sdrDed["FName"] != null)
                            ed._fName = sdrDed["FName"].ToString();
                        if (sdrDed["LName"] != null)
                            ed._lName = sdrDed["LName"].ToString();
                        if (sdrDed["PTOHours"] != null)
                            ed._pTO = decimal.Parse(sdrDed["PTOHours"].ToString());
                        ed._medInsDeduction = 0;
                        ed._dentInsDeduction = 0;
                        empList.Add(ed);
                    }
                }

                foreach (EmployeeDetail ed in empList)
                {
                    if (ed._fName == fName && ed._lName == lName)
                    {
                        pto = ed._pTO;
                    }
                }
                sdrDed.Close();
                return pto;
            }
            catch (Exception exc)
            {
                MessageBox.Show(exc.Message);
            }
            return pto;
        }

        //Get a list of all employees
        public List<Employee> GetEmployees()
        {
            List<Employee> empList = new List<Employee>();
            SqlDataReader sdrEmp = mt.GetEmployee();
            if (sdrEmp.HasRows)
            {
                while (sdrEmp.Read())
                {
                    Employee e = new Employee();
                    if (sdrEmp["empID"] != null)
                        e._empID = int.Parse(sdrEmp["empID"].ToString());
                    if (sdrEmp["FName"] != null)
                        e._fName = sdrEmp["FName"].ToString();
                    if (sdrEmp["LName"] != null)
                        e._lName = sdrEmp["LName"].ToString();
                    if (sdrEmp["Address"] != null)
                        e._address = sdrEmp["Address"].ToString();
                    if (sdrEmp["City"] != null)
                        e._city = sdrEmp["City"].ToString();
                    if (sdrEmp["State"] != null)
                        e._state = sdrEmp["State"].ToString();
                    if (sdrEmp["Zip"] != null)
                        e._zip = sdrEmp["Zip"].ToString();
                    if (sdrEmp["DoH"] != null)
                        e._doH = (DateTime)sdrEmp["DoH"];
                    if (sdrEmp["Phone"] != null)
                        e._phone = sdrEmp["Phone"].ToString();
                    if (sdrEmp["PayRate"] != null)
                        e._payRate = (Decimal)sdrEmp["PayRate"];
                    if (sdrEmp["Email"] != null)
                        e._email = sdrEmp["Email"].ToString();
                    empList.Add(e);
                }
            }
            sdrEmp.Close();
            return empList;
        }        

        //Retrieve a list of shifts by date range
        public List<Shift> GetShiftsByDate(DateTime startDate, DateTime endDate)
        {
            List<Shift> shiftList = new List<Shift>();
            SqlDataReader sdrShift = mt.GetShift();
            if (sdrShift.HasRows)
            {
                while (sdrShift.Read())
                {//FName, LName, Date, ShiftStart, ShiftEnd 
                    Shift s = new Shift();
                    if (sdrShift["FName"] != null)
                        s._fName = sdrShift["FName"].ToString();
                    if (sdrShift["LName"] != null)
                        s._lName = sdrShift["LName"].ToString();
                    if (sdrShift["Date"] != null)
                        s._date = (DateTime)sdrShift["Date"];
                    if (sdrShift["ShiftStart"] != null)
                        s._shiftStart = sdrShift["ShiftStart"].ToString();
                    if (sdrShift["ShiftEnd"] != null)
                        s._shiftEnd = sdrShift["ShiftEnd"].ToString();
                    if (s._date > startDate && s._date < endDate) shiftList.Add(s);
                }
            }
            sdrShift.Close();
            return shiftList;
        }

        //Retrieve a list of shifts by employee name
        public List<Shift> GetShiftsByName(string fName, string lName)
        {
            List<Shift> shiftList = new List<Shift>();
            SqlDataReader sdrShift = mt.GetShift();
            if (sdrShift.HasRows)
            {
                while (sdrShift.Read())
                {//FName, LName, Date, ShiftStart, ShiftEnd 
                    Shift s = new Shift();
                    if (sdrShift["FName"] != null)
                        s._fName = sdrShift["FName"].ToString();
                    if (sdrShift["LName"] != null)
                        s._lName = sdrShift["LName"].ToString();
                    if (sdrShift["Date"] != null)
                        s._date = (DateTime)sdrShift["Date"];
                    if (sdrShift["ShiftStart"] != null)
                        s._shiftStart = sdrShift["ShiftStart"].ToString();
                    if (sdrShift["ShiftEnd"] != null)
                        s._shiftEnd = sdrShift["ShiftEnd"].ToString();
                    if (fName == s._fName && lName == s._lName) shiftList.Add(s);
                }
            }
            sdrShift.Close();
            return shiftList;
        }
        #endregion

        #region textBoxFormatting

        private void TextBox_PreviewExecuted(object sender, ExecutedRoutedEventArgs e)
        {
            if (e.Command == ApplicationCommands.Paste) e.Handled = true;
        }

#endregion
    }
}

﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using PayrollApplication.Classes;
using System.Data.SqlClient;

namespace PayrollApplication.Windows
{
    /// <summary>
    /// Interaction logic for ShiftBrowse.xaml
    /// </summary>
    public partial class ShiftBrowse : Window
    {

        MidTier mt = new MidTier();

        public ShiftBrowse()
        {
            InitializeComponent();
            datSearchShiftEndDate.SelectedDate = DateTime.Today;
            datSearchShiftStartDate.SelectedDate = DateTime.Today;
            this.Shifts = new ObservableCollection<ShiftViewModel>();
            this.DataContext = this;
        }

        //Collection creation for data binding
        public ObservableCollection<ShiftViewModel> Shifts { get; private set; }      

        #region buttons
        private void btnSearchShiftByName_Click(object sender, RoutedEventArgs e)
        {
            Shifts.Clear();
            string fName = txtSearchShiftFName.Text;
            string lName = txtSearchShiftLName.Text;
            List<Shift> shiftList = GetShiftsByName(fName, lName);
            shiftList = shiftList.OrderBy(o => o._date).ToList();
            foreach (Shift s in shiftList)
            {
                var model = new ShiftViewModel
                {
                    empID = s._empID,
                    Name = s._fName + " " + s._lName,
                    Date = s._date.ToShortDateString(),
                    StartTime = s._shiftStart,
                    EndTime = s._shiftEnd
                };
                Shifts.Add(model);
            }
        }

        private void btnMainMenu_Click(object sender, RoutedEventArgs e)
    {
        dbMenu dbm = new dbMenu();
        dbm.Show();
        this.Close();
    }

        private void btnSearchShiftByDate_Click(object sender, RoutedEventArgs e)
        {
            Shifts.Clear();
            DateTime startDate = (DateTime)datSearchShiftStartDate.SelectedDate;
            DateTime endDate = (DateTime)datSearchShiftEndDate.SelectedDate;
            List<Shift> shiftList = GetShiftsByDate(startDate, endDate);
            shiftList = shiftList.OrderBy(o => o._empID).ToList();
            foreach (Shift s in shiftList)
            {
                var model = new ShiftViewModel
                {
                    empID = s._empID,
                    Name = s._fName + " " + s._lName,
                    Date = s._date.ToShortDateString(),
                    StartTime = s._shiftStart,
                    EndTime = s._shiftEnd
                };
                Shifts.Add(model);
            }
        }
#endregion

        #region getLists
        public List<Shift> GetShiftsByName(string fName, string lName)
        {
            List<Shift> shiftList = new List<Shift>();           
                SqlDataReader sdrShift = mt.GetShift();
                if (sdrShift.HasRows)
                {
                    while (sdrShift.Read())
                    {
                        Shift s = new Shift();
                        if (sdrShift["FName"] != null)
                            s._fName = sdrShift["FName"].ToString();
                        if (sdrShift["LName"] != null)
                            s._lName = sdrShift["LName"].ToString();
                        if (sdrShift["Date"] != null)
                            s._date = (DateTime)sdrShift["Date"];
                        if (sdrShift["ShiftStart"] != null)
                            s._shiftStart = sdrShift["ShiftStart"].ToString();
                        if (sdrShift["ShiftEnd"] != null)
                            s._shiftEnd = sdrShift["ShiftEnd"].ToString();
                        if(fName == s._fName && lName == s._lName ) shiftList.Add(s);
                    }
                }
                sdrShift.Close();
            return shiftList;
        }

        public List<Shift> GetShiftsByDate(DateTime startDate, DateTime endDate)
        {
            List<Shift> shiftList = new List<Shift>();
            SqlDataReader sdrShift = mt.GetShift();
            if (sdrShift.HasRows)
            {
                while (sdrShift.Read())
                {//FName, LName, Date, ShiftStart, ShiftEnd 
                    Shift s = new Shift();
                    if (sdrShift["FName"] != null)
                        s._fName = sdrShift["FName"].ToString();
                    if (sdrShift["LName"] != null)
                        s._lName = sdrShift["LName"].ToString();
                    if (sdrShift["Date"] != null)
                        s._date = (DateTime)sdrShift["Date"];
                    if (sdrShift["ShiftStart"] != null)
                        s._shiftStart = sdrShift["ShiftStart"].ToString();
                    if (sdrShift["ShiftEnd"] != null)
                        s._shiftEnd = sdrShift["ShiftEnd"].ToString();
                    if (s._date > startDate && s._date < endDate) shiftList.Add(s);
                }
            }
            sdrShift.Close();
            return shiftList;
        }
#endregion

    }
}

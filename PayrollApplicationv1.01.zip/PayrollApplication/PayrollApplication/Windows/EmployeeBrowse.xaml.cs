﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using PayrollApplication.Classes;
using System.Data.SqlClient;
using System.Collections.ObjectModel;
using PayrollApplication.Classes;

namespace PayrollApplication.Windows
{
    /// <summary>
    /// Interaction logic for EmployeeBrowse.xaml
    /// </summary>
    /// 
    public partial class EmployeeBrowse : Window
    {
        MidTier mt = new MidTier();
        

        public EmployeeBrowse()
        {
            InitializeComponent();
            this.Employees = new ObservableCollection<EmployeeViewModel>();
            this.DataContext = this;
        }

        //Collection creation for data binding
        public ObservableCollection<EmployeeViewModel> Employees { get; private set; }

        #region texBoxFormatting
        private void TextBox_PreviewExecuted(object sender, ExecutedRoutedEventArgs e)
        {
            if (e.Command == ApplicationCommands.Paste) e.Handled = true;
        }
#endregion

        #region buttons
        private void btnMainMenu_Click(object sender, RoutedEventArgs e)
        {
            dbMenu dbm = new dbMenu();
            dbm.Show();
            this.Close();
        }


        
        private void btnFindAllEmployees_Click(object sender, RoutedEventArgs e)
        {
            Employees.Clear();
            List<Employee> empList = GetEmployees();
            foreach (Employee emp in empList)
            {
                string p = emp._phone.Insert(0, "(");
                p = p.Insert(4, ") ");
                p = p.Insert(9, "-");
                var model = new EmployeeViewModel
                {
                    ID = emp._empID,
                    Name = emp._fName + " " + emp._lName,
                    Address = emp._address + ", " + emp._city + ", " + emp._state + " " + emp._zip,
                    HireDate = emp._doH.ToShortDateString(),
                    Phone = p,
                    PayRate = Math.Round(emp._payRate, 2),
                    Email = emp._email                    
                };
                Employees.Add(model);
            }

            
        }
        private void btnSearchByName_Click(object sender, RoutedEventArgs e)
        {
            Employees.Clear();
            string fName = txtSearchEmpFName.Text;
            string lName = txtSearchEmpLName.Text;
            List<Employee> empList = GetEmployeeByName(fName, lName);
            foreach (Employee emp in empList)
            {
                string p = emp._phone.Insert(0, "(");
                p = p.Insert(4, ") ");
                p = p.Insert(9, "-");
                var model = new EmployeeViewModel
                {
                    ID = emp._empID,
                    Name = emp._fName + " " + emp._lName,
                    Address = emp._address + ", " + emp._city + ", " + emp._state + " " + emp._zip,
                    HireDate = emp._doH.ToShortDateString(),
                    Phone = p,
                    PayRate = Math.Round(emp._payRate, 2),
                    Email = emp._email
                };
                Employees.Add(model);
            }
        }
#endregion

        #region GetLists

        //List to retrieve all employees
        public List<Employee> GetEmployees()
        {           
            List<Employee> empList = new List<Employee>();
            SqlDataReader sdrEmp = mt.GetEmployee();
            if (sdrEmp.HasRows)
            {
                while (sdrEmp.Read())
                {
                    Employee e = new Employee();
                    if (sdrEmp["empID"] != null)
                        e._empID = int.Parse(sdrEmp["empID"].ToString());
                    if (sdrEmp["FName"] != null)
                        e._fName = sdrEmp["FName"].ToString();
                    if (sdrEmp["LName"] != null)
                        e._lName = sdrEmp["LName"].ToString();
                    if (sdrEmp["Address"] != null)
                        e._address = sdrEmp["Address"].ToString();
                    if (sdrEmp["City"] != null)
                        e._city = sdrEmp["City"].ToString();
                    if (sdrEmp["State"] != null)
                        e._state = sdrEmp["State"].ToString();
                    if (sdrEmp["Zip"] != null)
                        e._zip = sdrEmp["Zip"].ToString();
                    if (sdrEmp["DoH"] != null)
                        e._doH = (DateTime)sdrEmp["DoH"];
                    if (sdrEmp["Phone"] != null)
                        e._phone = sdrEmp["Phone"].ToString();
                    if (sdrEmp["PayRate"] != null)
                        e._payRate = (Decimal)sdrEmp["PayRate"];
                    if (sdrEmp["Email"] != null)
                        e._email = sdrEmp["Email"].ToString();
                    empList.Add(e);
                }
            }
            sdrEmp.Close();
            return empList;
        }

        //List to retrieve employees by name
        public List<Employee> GetEmployeeByName(string firstName, string lastName)
        {
            List<Employee> empList = new List<Employee>();
            SqlDataReader sdrEmp = mt.GetEmployee();
            if (sdrEmp.HasRows)
            {
                while (sdrEmp.Read())
                {
                    Employee e = new Employee();
                    if (sdrEmp["empID"] != null)
                        e._empID = int.Parse(sdrEmp["empID"].ToString());
                    if (sdrEmp["FName"] != null)
                        e._fName = sdrEmp["FName"].ToString();
                    if (sdrEmp["LName"] != null)
                        e._lName = sdrEmp["LName"].ToString();
                    if (sdrEmp["Address"] != null)
                        e._address = sdrEmp["Address"].ToString();
                    if (sdrEmp["City"] != null)
                        e._city = sdrEmp["City"].ToString();
                    if (sdrEmp["State"] != null)
                        e._state = sdrEmp["State"].ToString();
                    if (sdrEmp["Zip"] != null)
                        e._zip = sdrEmp["Zip"].ToString();
                    if (sdrEmp["DoH"] != null)
                        e._doH = (DateTime)sdrEmp["DoH"];
                    if (sdrEmp["Phone"] != null)
                        e._phone = sdrEmp["Phone"].ToString();
                    if (sdrEmp["PayRate"] != null)
                        e._payRate = (Decimal)sdrEmp["PayRate"];
                    if (sdrEmp["Email"] != null)
                        e._email = sdrEmp["Email"].ToString();
                    if (e._fName == firstName && e._lName == lastName)
                                                        empList.Add(e);
                }
            }
            sdrEmp.Close();
            return empList;
        }

        #endregion

        #region randoms

        public void RandomShift()
        {
            List<Employee> empList = GetEmployees();
            foreach (Employee emp in empList)
            {
                Random rand = new Random();
                List<DateTime> shiftList = new List<DateTime>();
                for (int i = 0; i < ((DateTime.Today - emp._doH).Days) / 30; i++)
                {        
                    DateTime start = emp._doH;
                    int range = (DateTime.Today - start).Days;
                    DateTime shiftDate = start.AddDays(rand.Next(range));            
                    if (!shiftList.Contains(shiftDate)) shiftList.Add(shiftDate);
                }
                string[] shiftTimes = new string[] { "0000", "0015", "0030", "0045", "0100", "0115", "0130", "0145", "0200", "0215", "0230", "0245", "0300", "0315",
                    "0330", "0345", "0400", "0415", "0430", "0445", "0500", "0515", "0530", "0545", "0600", "0615", "0630", "0645", "0700", "0715", "0730", "0745",
                    "0800", "0815", "0830", "0845", "0900", "0915", "0930", "0945", "1000", "1015", "1030", "1045", "1100", "1115", "1130", "1145", "1200", "1215",
                    "1230", "1245", "1300", "1315", "1330", "1345", "1400", "1415", "1430", "1445", "1500", "1515", "1530", "1545", "1600", "1615", "1630", "1645",
                    "1700", "1715", "1730", "1745", "1800", "1815", "1830", "1845", "1900", "1915", "1930", "1945", "2000", "2015", "2030", "2045", "2100", "2115",
                    "2130", "2145", "2200", "2215", "2230", "2245", "2300", "2315", "2330", "2345" };
                foreach (DateTime dt in shiftList)
                {
                    int x = rand.Next(0, 12);
                    int y = rand.Next(4, 12);
                    TimeSpan start = TimeSpan.FromHours(x);
                    TimeSpan end = TimeSpan.FromHours(x + y);
                    decimal hoursWorked = (decimal)y;
                    int insertNewShift = mt.InsertNewShift(emp._lName, emp._fName, dt, start.ToString(), end.ToString(), hoursWorked);
                }

            }
        }

        DateTime randomDay()
        {
            Random rand = new Random();
            DateTime start = new DateTime(2015, 1, 1);
            int range = (DateTime.Today - start).Days;
            return start.AddDays(rand.Next(range));
        }
#endregion
    }
}

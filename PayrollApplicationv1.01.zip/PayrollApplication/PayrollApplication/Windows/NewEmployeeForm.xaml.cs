﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using PayrollApplication.Windows;
using System.Text.RegularExpressions;

namespace PayrollApplication.Windows
{
    /// <summary>
    /// Interaction logic for NewEmployeeForm.xaml
    /// </summary>
    public partial class NewEmployeeForm : Window
    {

        MidTier mt = new MidTier();

        public NewEmployeeForm()
        {
            InitializeComponent();
            radHourly.IsChecked = true;
            datEDoH.SelectedDate = DateTime.Today;
        }

        #region buttons
        private void btnMainMenu_Click(object sender, RoutedEventArgs e)
        {
            dbMenu dbm = new dbMenu();
            dbm.Show();
            this.Close();           
        }

        private void btnAddEmployee_Click(object sender, RoutedEventArgs e)
        {
            int empCat = 0;
            decimal dentalDeduction = 0;
            decimal medicalDeduction = 0;
            try
            {
                string fName = txtEFName.Text;
                string lName = txtELName.Text;
                string ssn = txtESSN.Text;
                DateTime doh = (DateTime)datEDoH.SelectedDate;
                string address = txtEAddress.Text;
                string city = txtECity.Text;
                string state = txtEState.Text;
                string zip = txtEZip.Text;
                bool stateCheck = false;
                string email = txtEEmail.Text;
                string phone = txtEPhone.Text;
                decimal payRate = Math.Round(decimal.Parse(txtEPayRate.Text), 2);
                if (radHourly.IsChecked == true) empCat = 1;
                else empCat = 2;

                string[] states = new string[] { "AL", "", "AK", "AS", "AZ", "AR", "CA", "CO", "CT", "DE", "DC", "FL",
                    "GA", "GU", "HI", "ID", "IL", "IN", "IA", "KS", "KY", "LA", "ME", "MD", "MH", "MA", "MI", "FM", "MN",
                    "MS", "MO", "MT", "NE", "NV", "NH", "NJ", "NM", "NY", "NC", "ND", "MP", "OH", "OK", "OR", "PW", "PA",
                    "PR", "RI", "SC", "SD", "TN", "TX", "UT", "VT", "VA", "VI", "WA", "WV", "WI", "WY" };

                //If dental insurance is checked, calculate deduction as 3% of annual salary
                if (empCat == 1 && chkDental.IsChecked == true)
                    dentalDeduction = ((payRate * (decimal)2085.72) / 24) * (decimal).03;
                if (empCat == 2 && chkDental.IsChecked == true)
                    dentalDeduction = (payRate / 24) * (decimal).03; 

                //If medical insurance is checked, calculate deduction as 6% of annual salary
                if (empCat == 1 && chkMedical.IsChecked == true)
                    medicalDeduction = ((payRate * (decimal)2085.72) / 24) * (decimal).06;
                if (empCat == 2 && chkMedical.IsChecked == true)
                    medicalDeduction = (payRate / 24) * (decimal).03;


                //Insert new employee
                if (((fName ?? lName ?? ssn ?? address ?? city ?? state ?? zip ?? email ?? phone) != null) && doh != null && empCat != null && payRate != null && medicalDeduction != null && dentalDeduction != null)
                {
                    foreach (string s in states)
                    {
                        if (s == state) stateCheck = true;
                    }

                    if (stateCheck == true)
                    {
                        if (email.Contains('@') && email.Contains('.'))
                        {
                            //arrays to confirm exact char count for required fields
                            char[] zipArray = zip.ToCharArray();
                            char[] phoneArray = phone.ToCharArray();
                            char[] stateArray = state.ToCharArray();
                            char[] ssnArray = ssn.ToCharArray();
                            if (zipArray.Count() == 5 && phone.Count() == 10 && stateArray.Count() == 2 && ssnArray.Count() == 9)
                            {
                                int insertNewEmployeeResult = mt.InsertNewEmployee(lName, fName, ssn, doh, address, city, state, zip, email, phone, payRate, empCat, medicalDeduction, dentalDeduction);
                                if (insertNewEmployeeResult == 2) MessageBox.Show("Employee has been added to the database.");
                                else MessageBox.Show("Error while adding employee. Rows added: " + insertNewEmployeeResult.ToString());
                            }
                            else MessageBox.Show("Please confirm that you have entered a valid zip code, phone number, two-digit state and SSN.\n");
                        }
                        else MessageBox.Show("Please enter a valid email address");
                    }
                    else MessageBox.Show("Please enter a valid two-digit state code.");
                }
                else MessageBox.Show("Please ensure all fields have a value");
            }
            catch(Exception exc)
            {
                MessageBox.Show(exc.Message);
            }
        }
#endregion

        #region textboxPreviewHandling
        private void TextBox_PreviewExecuted(object sender, ExecutedRoutedEventArgs e)
        {
            if (e.Command == ApplicationCommands.Paste) e.Handled = true;
        }
        private void txtESSN_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            e.Handled = !StringCharIsTextAllowed(e.Text);
        }

        private void txtEZip_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            e.Handled = !StringCharIsTextAllowed(e.Text);
        }

        private void txtEPhone_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            e.Handled = !StringCharIsTextAllowed(e.Text);
        }

        private void txtEPayRate_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            e.Handled = !IsTextAllowed(e.Text);
        }
        #endregion

        #region textboxFormatting

        //Method for handling non-numeric text input. 
        private static bool IsTextAllowed(string text)
        {
            Regex regex = new Regex("[^0-9.]"); //regex that matches disallowed text
            return !regex.IsMatch(text);
        }

        private static bool StringCharIsTextAllowed(string text)
        {
            Regex regex = new Regex("[^0-9]"); //regex that matches disallowed text
            return !regex.IsMatch(text);
        }

        #endregion

        //Methods and arrays for random data insertion
        #region randomTestSamples
        //Methods for inserting random data
        public void insertRandoms()
        {
            string[] fnames = new string[] { "Merry", "Ying", "Shelton", "Damion", "Ismael", "Bula", "Donna", "Leon", "Charles", "Brandy", "Davis", "Julianna", "Effie", "Kylie",
            "Lynette", "Eleanora", "Pamela", "Braedon", "Frankie", "Madilynn", "Kristian", "Alyson", "Precious", "Heath", "Mareli", "Kamryn", "Rene", "Destiny", "Ivan", "Nia", "" +
            "Karma", "Tabitha", "Isabella", "Raiden", "Reyna", "Dominic", "Daniel", "Kamila", "Albert", "Dixie", "Joshua", "Mylee", "Caitlyn", "Brian", "Annastasia", "Troy", "Briley",
            "Adonis", "Scarlett", "Anabelle", "Travis", "Giana", "Sterling", "Adalynn", "Ruben", "Greta", "Casey", "Emilee", "Jaydon", "Chloe", "Giovani", "Khalil", "Brisa", "Grayson",
            "Claire", "Saniya", "Michael", "Mckenzie", "Taniyah", "Justice", "Sonny", "Leslie", "Kimora", "Monique", "Christina", "Kyleigh", "Aiyana", "Mackenzie", "Carleigh",
            "Mareli", "Hayden", "Shelby", "Yurem", "Erika", "Adrien", "Logan", "Lewis", "Enzo", "Joaquin", "Remington", "Jordan", "Marcel", "Jessica", "Savion", "Amani",
            "Nora", "Samara", "Neveah", "Kymani", "Bobby", "James", "Anna", "Andrea", "Daniella", "Austin", "Jesse", "Jake", "Christopher", "Matthew", "Todd", "James"};

            string[] lnames = new string[] {"McCoy", "Pitts", "Dominguez", "Deleon", "Booth", "Donovan", "Larson", "Nollette", "Richards", "Singh", "Simon", "Cannon", "Cabrera", "Ali",
                "Schultz", "Valdez", "Lynn", "Huffman", "Williams", "Rogers", "Harrell", "Boyd", "Harris", "Lowe", "Knox", "Barker", "House", "Hester", "Lozano", "Vang", "French",
                "Torres", "Harmon", "Hughes", "Smith", "Franklin", "Wallace", "Waller", "Schmidt", "Patel", "Owens", "Moyer", "Acosta", "Hobbs", "Jacobs", "Mcgrath", "Sloan", "Guerra",
                "Santana", "Swanson", "Stevens", "Bryant", "Avery", "Sutton", "Lucas", "Harris", "Jacobson", "Stuart", "Dunlap", "Foley", "Cisneros", "Cruz", "Ballard", "Allen", "Holden",
                "Fleming", "Morrison", "Bridges", "Combs", "Glenn", "Estes", "Hines", "Patrick", "Stafford", "Berger", "Waller", "Hill", "Norton", "Cherry", "Davids", "Stout", "Mejia",
                "Sullivan", "Perez", "Quinn", "Kemp", "Lang", "Fletcher", "Holland", "Christian", "Huang", "Bush", "Willis", "Turner", "Hanson", "Mclaughlin", "Day", "Schaefer", "Cannon",
                "Mullins", "Avila", "Forbes", "Richardson", "Decamps" };

            string[] directions = new string[] { "East", "North", "South", "West", "Northwest", "Southwest", "Northeast", "Southeast" };
            string[] streets = new string[] { "Main", "Sherman", "Mill", "Forest", "Hickory", "York", "Pleasant", "Holly", "Mechanic", "Forest", "Walnut", "5th", "Hawthorne", "Myrtle", "Dogwood",
                "Mulberrry", "Cherry", "Sunset", "Andover", "Laurel", "Garfield", "Cooper", "Lafayette", "Aspen", "Linda", "Surrey", "Ann", "10th", "12th", "Oxford", "6th", "7th", "8th", "9th",
                "1st", "2nd", "3rd", "4th", "Magnolia", "Wall", "Lincoln", "Pheasant", "Washington", "Locust", "Inverness", "Marshall", "West", "Cedar", "Pennsylvania", "Brown",
                "Carriage", "Maple", "Homestead", "Essex" };
            string[] streetSuffx = new string[] { "St", "Ave", "Ct", "Way", "Blvd", "Lane", "Landing", "Lodge", "Park", "Parkway", "Pass", "Plaza", "Route", "Terrace" };
            string[] cities = new string[]
            {
                "Seattle", "Bellevue", "Renton", "Mercer Island", "Columbia City", "Newcastle", "Issaquah", "Tukwila", "Burien", "Des Moines", "Kent", "Federal Way", "Shoreline", "Bothell", "Auburn", "Tacoma", "Maple Valley", "Covington", "Redmond", "Woodinville", "Mountlake Terrace", "Edmonds" };


            string[] phoneprefix = new string[] { "206", "425", "253" };
            Random rand = new Random();
            for (int i = 0; i < 500; i++)
            {
                string address = rand.Next(1000, 9999).ToString() + " " + directions[rand.Next(0, directions.Length)] + " " + streets[rand.Next(0, streets.Length)] + " " + streetSuffx[rand.Next(0, streetSuffx.Length)];
                string fName = fnames[rand.Next(0, fnames.Length)];
                string lName = lnames[rand.Next(0, lnames.Length)];


                int r = rand.Next(0, 8);
                int empCat = 0;
                decimal payRate = 0;
                if (r <= 1)
                {
                    empCat = 2;
                    payRate = rand.Next(30000, 70000);
                }
                else
                {
                    empCat = 1;
                    payRate = rand.Next(11, 30);
                }
                string email = fName + "." + lName + "@payroll.com";
                DateTime start = new DateTime(1995, 1, 1);
                int range = (DateTime.Today - start).Days;
                DateTime doh = start.AddDays(rand.Next(range));
                int insertNewEmployeeResult = mt.InsertNewEmployee(lName, fName, rand.Next(100000000, 999999999).ToString(), doh, address, cities[rand.Next(0, cities.Length)], "WA", rand.Next(98000, 98288).ToString(), email , phoneprefix[rand.Next(0, phoneprefix.Length)] + rand.Next(1000000, 9999999), payRate, empCat, rand.Next(20, 40), rand.Next(10, 25));
            }

        }

        DateTime randomDay()
        {
            Random rand = new Random();
            DateTime start = new DateTime(1995, 1, 1);
            int range = (DateTime.Today - start).Days;
            return start.AddDays(rand.Next(range));
        }
#endregion
    }
}



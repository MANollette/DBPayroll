﻿using PayrollApplication.Classes;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace PayrollApplication.Windows
{
    /// <summary>
    /// Interaction logic for EmployeeUpdate.xaml
    /// </summary>
    public partial class EmployeeUpdate : Window
    {

        //Initialize midtier
        MidTier mt = new MidTier();

        public EmployeeUpdate()
        {
            InitializeComponent();
        }

        #region Buttons
        private void btnMainMenu_Click(object sender, RoutedEventArgs e)
        {
            dbMenu dbm = new dbMenu();
            dbm.Show();
            this.Close();
        }

        private void btnUpdateEmpName_Click(object sender, RoutedEventArgs e)
        {
            if (txtUNIDCheck.Text != "" && txtUNFNameCheck.Text != "" && txtUNLNameCheck.Text != "")
            {
                if (txtUNNewEmpFName.Text == "" && txtUNNewEmpLName.Text != "")
                {
                    int x = mt.UpdateName(int.Parse(txtUNIDCheck.Text), txtUNFNameCheck.Text, txtUNLNameCheck.Text, txtUNFNameCheck.Text, txtUNNewEmpLName.Text);
                    if (x == 1)
                        MessageBox.Show("Name successfully updated.");
                    else if (x == 0)
                        MessageBox.Show("Employee name not found.");
                    else
                        MessageBox.Show("Something went wrong. \n{0} rows were updated.", x.ToString());
                }
                else if (txtUNNewEmpFName.Text != "" && txtUNNewEmpLName.Text == "")
                {
                    int x = mt.UpdateName(int.Parse(txtUNIDCheck.Text), txtUNFNameCheck.Text, txtUNLNameCheck.Text, txtUNNewEmpFName.Text, txtUNLNameCheck.Text);
                    if (x == 1)
                        MessageBox.Show("Name successfully updated.");
                    else if (x == 0)
                        MessageBox.Show("Employee name not found.");
                    else
                        MessageBox.Show("Something went wrong. \n{0} rows were updated.", x.ToString());
                }
                else if (txtUNNewEmpFName.Text == "" && txtUNNewEmpLName.Text == "")
                {
                    MessageBox.Show("Please enter a new first and/or last name for the 'new entry' fields.");
                }
                else
                {
                    //MidTier executes nonquery so as to return number of rows updated. int x is the number of rows
                    int x = mt.UpdateName(int.Parse(txtUNIDCheck.Text), txtUNFNameCheck.Text, txtUNLNameCheck.Text, txtUNNewEmpFName.Text, txtUNNewEmpLName.Text);
                    if (x == 1)
                        MessageBox.Show("Name successfully updated.");
                    else if (x == 0)
                        MessageBox.Show("Employee name not found.");
                    else
                        MessageBox.Show("Something went wrong. \n{0} rows were updated.", x.ToString());
                }
            }
            else
                MessageBox.Show("Please make sure you have input a value in the current \nID, First Name and Last Name fields.");
        }

        private void btnUpdateEmpContactInfo_Click(object sender, RoutedEventArgs e)
        {

            try
            {
                if (txtUCIIDCheck.Text != "" && txtUCIFNameCheck.Text != "" && txtUCILNameCheck.Text != "")
                {
                    List<Employee> empList = GetEmployees();
                    Employee emp = new Employee(-1, "", "", "", DateTime.Now, "", "", "", "", "", "", (Decimal)0.0);
                    foreach (Employee empl in empList)
                    {
                        if (empl._fName == txtUCIFNameCheck.Text && empl._lName == txtUCILNameCheck.Text && empl._empID == int.Parse(txtUCIIDCheck.Text))
                        {
                            emp = empl;
                        }
                    }
                    //Initialize 
                    string address = emp._address;
                    string city = emp._city;
                    string state = emp._state;
                    bool stateCheck = false;
                    string[] states = new string[] { "AL", "", "AK", "AS", "AZ", "AR", "CA", "CO", "CT", "DE", "DC", "FL",
                    "GA", "GU", "HI", "ID", "IL", "IN", "IA", "KS", "KY", "LA", "ME", "MD", "MH", "MA", "MI", "FM", "MN",
                    "MS", "MO", "MT", "NE", "NV", "NH", "NJ", "NM", "NY", "NC", "ND", "MP", "OH", "OK", "OR", "PW", "PA",
                    "PR", "RI", "SC", "SD", "TN", "TX", "UT", "VT", "VA", "VI", "WA", "WV", "WI", "WY" };
                    string zip = emp._zip;
                    string email = emp._email;                    
                    string phone = emp._phone;
                    foreach (string s in states)
                        if (s == state) stateCheck = true;
                    if (emp._empID != -1)
                    {
                        if (stateCheck == true)
                        {
                            if (txtUCINewEmail.Text != "") email = txtUCINewEmail.Text;
                            if (email.Contains('@') && email.Contains('.'))
                            {
                                if (txtUCINewAddress.Text != "") address = txtUCINewAddress.Text;
                                if (txtUCINewCity.Text != "") city = txtUCINewCity.Text;
                                if (txtUCINewState.Text != "")
                                {
                                    if (txtUCINewState.Text.Count() == 2)
                                        state = txtUCINewState.Text;
                                    else MessageBox.Show("Make sure you have entered a valid \ntwo-character state code.");
                                }
                                if (txtUCINewZip.Text != "")
                                {
                                    if (txtUCINewZip.Text.Count() == 5) zip = txtUCINewZip.Text;
                                    else MessageBox.Show("Please enter a valid five-character zip code.");
                                }
                                
                                if (txtUCINewPhone.Text != "")
                                {
                                    if (txtUCINewPhone.Text.Count() == 10) phone = txtUCINewPhone.Text;
                                    else MessageBox.Show("Please enter a valid ten-character phone number.");
                                }

                                int x = mt.UpdateContact(int.Parse(txtUCIIDCheck.Text), txtUCIFNameCheck.Text, txtUCILNameCheck.Text, address, city, state, zip, email, phone);

                                if (x == 1)
                                    MessageBox.Show("Contact Info successfully updated.");
                                else if (x == 0)
                                    MessageBox.Show("Employee name not found.");
                                else
                                    MessageBox.Show("Something went wrong. \n{0} rows were updated.", x.ToString());
                            }
                            else MessageBox.Show("Please enter a valid email format.");
                        }
                        else MessageBox.Show("Please enter a valid two-digit state code.");
                    }
                    else MessageBox.Show("Employee not found. \nPlease ensure your employee ID matches the first and\nlast names entered.");
                }
                else
                    MessageBox.Show("Please enter a valid employee first name, last name and ID to update. ");
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnUWI_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (txtUWFNameCheck.Text != "" && txtUWLNameCheck.Text != "" && txtUWIDCheck.Text != "")
                {
                    if (txtUWNewPayRate.Text != "")
                    {
                        if (radUWHourly.IsChecked == true || radUWSalary.IsChecked == true)
                        {
                            int empCat = -1;
                            if (radUWHourly.IsChecked == true) empCat = 1;
                            if (radUWSalary.IsChecked == true) empCat = 2;

                            int x = mt.UpdatePayInfo(int.Parse(txtUWIDCheck.Text), txtUWFNameCheck.Text, txtUWLNameCheck.Text, decimal.Parse(txtUWNewPayRate.Text), empCat);

                            if (x == 2)
                                MessageBox.Show("Pay Rate info successfully updated.");
                            else if (x == 0)
                                MessageBox.Show("Employee name not found.");
                            else
                                MessageBox.Show("Something went wrong. \nUpdated row count:" + x.ToString());
                        }
                        else MessageBox.Show("Please select whether this is an hourly or annual rate.");
                    }
                    else MessageBox.Show("Please enter a valid new pay rate.");
                }
                else MessageBox.Show("Please ensure you enter a valid current employee \nfirst name, last name and ID number");
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnUpdateInsurance_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (txtUIOFNameCheck.Text != "" && txtUIOIDCheck.Text != "" && txtUIOLNameCheck.Text != "")
                {
                    List<EmployeeDetail> empList = GetEmployeeDetails();
                    EmployeeDetail emp = new EmployeeDetail("", "", (Decimal)(-1), (Decimal)(-1), (Decimal)(-1));
                    foreach(EmployeeDetail empl in empList)
                    {
                        if (empl._fName == txtUIOFNameCheck.Text && empl._lName == txtUIOLNameCheck.Text) emp = empl;
                    }

                    int x = -1;

                    if (txtUIONewMedDed.Text != "" && txtUIONewDentDed.Text == "")
                    {
                        x = mt.UpdateInsuranceInfo(int.Parse(txtUIOIDCheck.Text), txtUIOFNameCheck.Text, txtUIOLNameCheck.Text, decimal.Parse(txtUIONewMedDed.Text), emp._dentInsDeduction);
                        if (x == 1)
                            MessageBox.Show("Insurance info successfully updated.");
                        else if (x == 0)
                            MessageBox.Show("Employee name not found.");
                        else
                            MessageBox.Show("Something went wrong. \nUpdated row count:" + x.ToString());
                    }
                    else if (txtUIONewMedDed.Text == "" && txtUIONewDentDed.Text != "")
                    {
                        x = mt.UpdateInsuranceInfo(int.Parse(txtUIOIDCheck.Text), txtUIOFNameCheck.Text, txtUIOLNameCheck.Text, emp._medInsDeduction, decimal.Parse(txtUIONewDentDed.Text));
                        if (x == 1)
                            MessageBox.Show("Insurance info successfully updated.");
                        else if (x == 0)
                            MessageBox.Show("Employee name not found.");
                        else
                            MessageBox.Show("Something went wrong. \nUpdated row count:" + x.ToString());
                    }
                    else if (txtUIONewMedDed.Text == "" && txtUIONewDentDed.Text == "")
                    {
                        MessageBox.Show("Please enter a new medical and/or dental \ninsurance deduction amount.");
                    }
                    else if (txtUIONewMedDed.Text != "" && txtUIONewDentDed.Text != "")
                    {
                        x = mt.UpdateInsuranceInfo(int.Parse(txtUIOIDCheck.Text), txtUIOFNameCheck.Text, txtUIOLNameCheck.Text, decimal.Parse(txtUIONewMedDed.Text), decimal.Parse(txtUIONewDentDed.Text));
                        if (x == 1)
                            MessageBox.Show("Insurance info successfully updated.");
                        else if (x == 0)
                            MessageBox.Show("Employee name not found.");
                        else
                            MessageBox.Show("Something went wrong. \nUpdated row count:" + x.ToString());
                    }

                    
                }
                else MessageBox.Show("Please enter a valid first name, last name and \nemployee ID.");
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void TextBox_PreviewExecuted(object sender, ExecutedRoutedEventArgs e)
        {
            if (e.Command == ApplicationCommands.Paste) e.Handled = true;
        }

        #endregion

        #region textboxPreviewHandling

        #region textboxFormatting

        //Method for handling non-numeric text input. 
        private static bool DecimalIsTextAllowed(string text)
        {
            Regex regex = new Regex("[^0-9.]"); //regex that matches disallowed text
            return !regex.IsMatch(text);
        }

        private static bool StringCharIsTextAllowed(string text0)
        {
            Regex regex = new Regex("[^0-9]");
            return !regex.IsMatch(text0);
        }

        #endregion

        #region TextHandling
        private void txtUNIDCheck_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            e.Handled = !StringCharIsTextAllowed(e.Text);
        }

        private void txtUCIIDCheck_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            e.Handled = !StringCharIsTextAllowed(e.Text);
        }

        private void txtUWIDCheck_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            e.Handled = !StringCharIsTextAllowed(e.Text);
        }

        private void txtUIOIDCheck_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            e.Handled = !StringCharIsTextAllowed(e.Text);
        }

        private void txtUIONewMedDed_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            e.Handled = !DecimalIsTextAllowed(e.Text);
        }

        private void txtUIONewDentDed_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            e.Handled = !DecimalIsTextAllowed(e.Text);
        }

        private void txtUWNewPayRate_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            e.Handled = !DecimalIsTextAllowed(e.Text);
        }

        private void txtUCINewPhone_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            e.Handled = !StringCharIsTextAllowed(e.Text);
        }

        private void txtUCINewZip_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            e.Handled = !StringCharIsTextAllowed(e.Text);
        }
        #endregion

        #endregion

        #region GetLists

        //List to retrieve all employees
        public List<Employee> GetEmployees()
        {
            List<Employee> empList = new List<Employee>();
            SqlDataReader sdrEmp = mt.GetEmployee();
            if (sdrEmp.HasRows)
            {
                while (sdrEmp.Read())
                {
                    Employee e = new Employee();
                    if (sdrEmp["empID"] != null)
                        e._empID = int.Parse(sdrEmp["empID"].ToString());
                    if (sdrEmp["FName"] != null)
                        e._fName = sdrEmp["FName"].ToString();
                    if (sdrEmp["LName"] != null)
                        e._lName = sdrEmp["LName"].ToString();
                    if (sdrEmp["Address"] != null)
                        e._address = sdrEmp["Address"].ToString();
                    if (sdrEmp["City"] != null)
                        e._city = sdrEmp["City"].ToString();
                    if (sdrEmp["State"] != null)
                        e._state = sdrEmp["State"].ToString();
                    if (sdrEmp["Zip"] != null)
                        e._zip = sdrEmp["Zip"].ToString();
                    if (sdrEmp["DoH"] != null)
                        e._doH = (DateTime)sdrEmp["DoH"];
                    if (sdrEmp["Phone"] != null)
                        e._phone = sdrEmp["Phone"].ToString();
                    if (sdrEmp["PayRate"] != null)
                        e._payRate = (Decimal)sdrEmp["PayRate"];
                    if (sdrEmp["Email"] != null)
                        e._email = sdrEmp["Email"].ToString();
                    empList.Add(e);
                }
            }
            sdrEmp.Close();
            return empList;
        }

        //List to retrieve employees by name
        public List<Employee> GetEmployeeByName(string firstName, string lastName)
        {
            List<Employee> empList = new List<Employee>();
            SqlDataReader sdrEmp = mt.GetEmployee();
            if (sdrEmp.HasRows)
            {
                while (sdrEmp.Read())
                {
                    Employee e = new Employee();
                    if (sdrEmp["empID"] != null)
                        e._empID = int.Parse(sdrEmp["empID"].ToString());
                    if (sdrEmp["FName"] != null)
                        e._fName = sdrEmp["FName"].ToString();
                    if (sdrEmp["LName"] != null)
                        e._lName = sdrEmp["LName"].ToString();
                    if (sdrEmp["Address"] != null)
                        e._address = sdrEmp["Address"].ToString();
                    if (sdrEmp["City"] != null)
                        e._city = sdrEmp["City"].ToString();
                    if (sdrEmp["State"] != null)
                        e._state = sdrEmp["State"].ToString();
                    if (sdrEmp["Zip"] != null)
                        e._zip = sdrEmp["Zip"].ToString();
                    if (sdrEmp["DoH"] != null)
                        e._doH = (DateTime)sdrEmp["DoH"];
                    if (sdrEmp["Phone"] != null)
                        e._phone = sdrEmp["Phone"].ToString();
                    if (sdrEmp["PayRate"] != null)
                        e._payRate = (Decimal)sdrEmp["PayRate"];
                    if (sdrEmp["Email"] != null)
                        e._email = sdrEmp["Email"].ToString();
                    if (e._fName == firstName && e._lName == lastName)
                        empList.Add(e);
                }
            }
            sdrEmp.Close();
            return empList;
        }

        public List<EmployeeDetail> GetEmployeeDetails()
        {
            List<EmployeeDetail> empList = new List<EmployeeDetail>();
            try
            {
                SqlDataReader sdrDed = mt.GetDeductions();
                if (sdrDed.HasRows)
                {
                    while (sdrDed.Read())
                    {
                        EmployeeDetail ed = new EmployeeDetail();
                        if (sdrDed["FName"] != null)
                            ed._fName = sdrDed["FName"].ToString();
                        if (sdrDed["LName"] != null)
                            ed._lName = sdrDed["LName"].ToString();
                        if (sdrDed["MedInsDeduction"] != null)
                            ed._medInsDeduction = decimal.Parse(sdrDed["MedInsDeduction"].ToString());
                        if (sdrDed["DentInsDeduction"] != null)
                            ed._dentInsDeduction = decimal.Parse(sdrDed["DentInsDeduction"].ToString());
                        ed._pTO = 0;
                        empList.Add(ed);
                    }
                }
                sdrDed.Close();
                return empList;
            }
            catch (Exception exc)
            {
                MessageBox.Show(exc.Message);
            }
            return empList;
        }

        #endregion

        
    }
}

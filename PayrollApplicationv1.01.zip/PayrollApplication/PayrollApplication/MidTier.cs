﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;

namespace PayrollApplication
{
    class MidTier
    {
        SqlConnection scon = new SqlConnection();
        SqlCommand scmd = new SqlCommand();

        public MidTier()
        {
            scon.ConnectionString = "Data Source=(local)\\SQLEXPRESS;Initial Catalog=DBPayroll;Integrated Security=True";
        }


        #region Select
        public SqlDataReader GetShift()
        {
            try
            {
                scon.Open();
                scmd.Connection = scon;
                scmd.Parameters.Clear();
                scmd.CommandType = CommandType.StoredProcedure;
                scmd.CommandText = "GetShift";
                return scmd.ExecuteReader(CommandBehavior.CloseConnection);
            }
            catch (SqlException)
            {
                return null;
            }
            catch (Exception)
            {
                return null;
            }
        }

        public int ShiftCount()
        {
            using (SqlConnection dbConnect = new SqlConnection())
            {
                SqlCommand shiftCount = new SqlCommand();
                try
                {
                    //create connection with database. Specify procedure to use (insert new employee)
                    dbConnect.ConnectionString = scon.ConnectionString;
                    dbConnect.Open();
                    shiftCount.Connection = dbConnect;
                    shiftCount.CommandType = CommandType.StoredProcedure;
                    shiftCount.CommandText = "shiftCount";

                    int keyReturn = (Int32)shiftCount.ExecuteScalar();
                    return keyReturn;
                }
                catch (SqlException se)
                {
                    return -3;
                }
                catch (Exception ex)
                {
                    return -5;
                }
            }
        }

        public SqlDataReader GetTimesheet()
        {
            try
            {
                scon.Open();
                scmd.Connection = scon;
                scmd.Parameters.Clear();
                scmd.CommandType = CommandType.StoredProcedure;
                scmd.CommandText = "GetTimesheet";
                return scmd.ExecuteReader(CommandBehavior.CloseConnection);
            }
            catch (SqlException)
            {
                return null;
            }
            catch (Exception)
            {
                return null;
            }
        }

        public SqlDataReader GetEmployee()
        {
            try
            {
                scon.Open();
                scmd.Connection = scon;
                scmd.Parameters.Clear();
                scmd.CommandType = CommandType.StoredProcedure;
                scmd.CommandText = "GetEmployee";
                return scmd.ExecuteReader(CommandBehavior.CloseConnection);
            }
            catch (SqlException)
            {
                return null;
            }
            catch (Exception)
            {
                return null;
            }
        }

        public SqlDataReader GetDeductions()
        {
            try
            {
                //create connection with database. Specify procedure to use (insert new employee)
                scon.Open();
                scmd.Connection = scon;
                scmd.Parameters.Clear();
                scmd.CommandType = CommandType.StoredProcedure;
                scmd.CommandText = "getDeductions";
                return scmd.ExecuteReader(CommandBehavior.CloseConnection);
            }
            catch (SqlException se)
            {
                return null;
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public SqlDataReader GetPTO()
        {
            try
            {
                //create connection with database. Specify procedure to use (insert new employee)
                scon.Open();
                scmd.Connection = scon;
                scmd.Parameters.Clear();
                scmd.CommandType = CommandType.StoredProcedure;
                scmd.CommandText = "GetPTO";
                return scmd.ExecuteReader(CommandBehavior.CloseConnection);
            }
            catch (SqlException se)
            {
                return null;
            }
            catch (Exception ex)
            {
                return null;
            }
        }
        #endregion

        #region Insert


        public int InsertNewShift(string lName, string fName, DateTime shiftDate, string shiftStart, string shiftEnd, decimal hoursWorked)
        {
            using (SqlConnection dbConnect = new SqlConnection())
            {
                SqlCommand newShift = new SqlCommand();
                try
                {
                    //create connection with database. Specify procedure to use (insert new employee)
                    dbConnect.ConnectionString = scon.ConnectionString;
                    dbConnect.Open();
                    newShift.Connection = dbConnect;
                    newShift.CommandType = CommandType.StoredProcedure;
                    newShift.CommandText = "InsertNewShift";
                    newShift.Parameters.Clear();

                    newShift.Parameters.Add("@LName", SqlDbType.VarChar).Value = lName;
                    newShift.Parameters.Add("@FName", SqlDbType.VarChar).Value = fName;
                    newShift.Parameters.Add("@date", SqlDbType.Date).Value = shiftDate;
                    newShift.Parameters.Add("@ShiftStart", SqlDbType.Time).Value = shiftStart;
                    newShift.Parameters.Add("@ShiftEnd", SqlDbType.Time).Value = shiftEnd;
                    newShift.Parameters.Add("@HoursWorked", SqlDbType.VarChar).Value = hoursWorked;

                    int keyReturn = Convert.ToInt32(newShift.ExecuteScalar());
                    return keyReturn;
                }
                catch (SqlException se)
                {
                    return -3;
                }
                catch (Exception ex)
                {
                    return -5;
                }
            }
        }

        public int InsertNewTimesheet(string lName, string fName, string shiftType, DateTime startDate, DateTime endDate, decimal oTHours, decimal taxRate, decimal deductions)
        {
            using (SqlConnection dbConnect = new SqlConnection())
            {
                SqlCommand newTS = new SqlCommand();
                try
                {
                    //create connection with database. Specify procedure to use (insert new employee)
                    dbConnect.ConnectionString = scon.ConnectionString;
                    dbConnect.Open();
                    newTS.Connection = dbConnect;
                    newTS.CommandType = CommandType.StoredProcedure;
                    newTS.CommandText = "InsertNewTimesheet";
                    newTS.Parameters.Clear();

                    newTS.Parameters.Add("@LName", SqlDbType.VarChar).Value = lName;
                    newTS.Parameters.Add("@FName", SqlDbType.VarChar).Value = fName;
                    newTS.Parameters.Add("@ShiftType", SqlDbType.Char).Value = shiftType;
                    newTS.Parameters.Add("@StartDate", SqlDbType.Date).Value = startDate;
                    newTS.Parameters.Add("@EndDate", SqlDbType.Date).Value = endDate;
                    newTS.Parameters.Add("@OTHours", SqlDbType.Decimal).Value = oTHours;
                    newTS.Parameters.Add("@TaxRate", SqlDbType.Decimal).Value = taxRate;
                    newTS.Parameters.Add("@Deductions", SqlDbType.Decimal).Value = deductions;

                    int keyReturn = Convert.ToInt32(newTS.ExecuteNonQuery());
                    return keyReturn;
                }
                catch (SqlException se)
                {
                    return -3;
                }
                catch (Exception ex)
                {
                    return -5;
                }
            }
        }

        /*Method to update customer first name
        public int UpdateFName(int cid, string fName)
        {
            using (SqlConnection dbConnect = new SqlConnection())
            {
                SqlCommand newUser = new SqlCommand();
                try
                {
                    //Karen
                    dbConnect.ConnectionString = "Data Source=J109-15;Initial Catalog=MANHammerStudiosDB;Integrated Security=True";

                    //Christy
                    //dbConnect.ConnectionString = "Data Source=J110-13;Initial Catalog=MANHammerStudiosDB;Integrated Security=True";

                    dbConnect.Open();
                    newUser.Connection = dbConnect;
                    newUser.CommandType = CommandType.StoredProcedure;
                    newUser.CommandText = "updateFName";
                    newUser.Parameters.Clear();
                    newUser.Parameters.Add("@custID", SqlDbType.Int).Value = cid;
                    newUser.Parameters.Add("@fName", SqlDbType.NVarChar, 30).Value = fName;
                    int keyReturn = Convert.ToInt32(newUser.ExecuteScalar());
                    return keyReturn;
                }
                catch (SqlException se)
                {
                    return -3;
                }
                catch (Exception ex)
                {
                    return -5;
                }
            }
        }
        */

        public int InsertNewEmployee(string lName, string fName, string ssn, DateTime doH, string address, string city,
                              string state, string zip, string email, string phone, decimal payRate, int empCat,
                              decimal medInsDed, decimal dentInsDed)
        {
            using (SqlConnection dbConnect = new SqlConnection())
            {
                SqlCommand newEmployee = new SqlCommand();
                try
                {
                    //create connection with database. Specify procedure to use (insert new employee)
                    dbConnect.ConnectionString = scon.ConnectionString;
                    dbConnect.Open();
                    newEmployee.Connection = dbConnect;
                    newEmployee.CommandType = CommandType.StoredProcedure;
                    newEmployee.CommandText = "InsertNewEmployee";
                    newEmployee.Parameters.Clear();

                    #region paramInsert
                    newEmployee.Parameters.Add("@LName", SqlDbType.VarChar).Value = lName;
                    newEmployee.Parameters.Add("@FName", SqlDbType.VarChar).Value = fName;
                    newEmployee.Parameters.Add("@SSN", SqlDbType.VarChar).Value = ssn;
                    newEmployee.Parameters.Add("@DoH", SqlDbType.Date).Value = doH;
                    newEmployee.Parameters.Add("@Address", SqlDbType.VarChar).Value = address;
                    newEmployee.Parameters.Add("@City", SqlDbType.VarChar).Value = city;
                    newEmployee.Parameters.Add("@State", SqlDbType.VarChar).Value = state;
                    newEmployee.Parameters.Add("@Zip", SqlDbType.VarChar).Value = zip;
                    newEmployee.Parameters.Add("@Email", SqlDbType.VarChar).Value = email;
                    newEmployee.Parameters.Add("@Phone", SqlDbType.VarChar).Value = phone;
                    newEmployee.Parameters.Add("@payRate", SqlDbType.Money).Value = payRate;
                    newEmployee.Parameters.Add("@empCat", SqlDbType.Int).Value = empCat;
                    newEmployee.Parameters.Add("@MedInsDeduction", SqlDbType.VarChar).Value = medInsDed;
                    newEmployee.Parameters.Add("@DentInsDeduction", SqlDbType.VarChar).Value = dentInsDed;
                    #endregion

                    int keyReturn = Convert.ToInt32(newEmployee.ExecuteNonQuery());
                    return keyReturn;
                }
                catch (SqlException se)
                {
                    return -3;
                }
                catch (Exception ex)
                {
                    return -5;
                }
            }
        }

        #endregion

        #region Update

        public int UpdatePTO(string fName, string lName, decimal addedPTO)
        {
            using (SqlConnection dbConnect = new SqlConnection())
            {
                SqlCommand newShift = new SqlCommand();
                try
                {
                    //create connection with database. Specify procedure to use (insert new employee)
                    dbConnect.ConnectionString = scon.ConnectionString;
                    dbConnect.Open();
                    newShift.Connection = dbConnect;
                    newShift.CommandType = CommandType.StoredProcedure;
                    newShift.CommandText = "InsertNewShift";
                    newShift.Parameters.Clear();

                    newShift.Parameters.Add("@FName", SqlDbType.VarChar).Value = fName;
                    newShift.Parameters.Add("@LName", SqlDbType.VarChar).Value = lName;
                    newShift.Parameters.Add("@AddedPTO", SqlDbType.Date).Value = addedPTO;

                    int keyReturn = Convert.ToInt32(newShift.ExecuteScalar());
                    return keyReturn;
                }
                catch (SqlException se)
                {
                    return -3;
                }
                catch (Exception ex)
                {
                    return -5;
                }
            }
        }

        public int UpdateName(int empID, string fNameCheck, string lNameCheck, string fName, string lName)
        {
            using (SqlConnection dbConnect = new SqlConnection())
            {
                SqlCommand newShift = new SqlCommand();
                try
                {
                    //create connection with database. Specify procedure to use (insert new employee)
                    dbConnect.ConnectionString = scon.ConnectionString;
                    dbConnect.Open();
                    newShift.Connection = dbConnect;
                    newShift.CommandType = CommandType.StoredProcedure;
                    newShift.CommandText = "UpdateEmpName";
                    newShift.Parameters.Clear();

                    newShift.Parameters.Add("@EmpID", SqlDbType.Int).Value = empID;
                    newShift.Parameters.Add("@FNameCheck", SqlDbType.VarChar).Value = fNameCheck;
                    newShift.Parameters.Add("@LNameCheck", SqlDbType.VarChar).Value = lNameCheck;
                    newShift.Parameters.Add("@FName", SqlDbType.VarChar).Value = fName;
                    newShift.Parameters.Add("@LName", SqlDbType.VarChar).Value = lName;

                    int keyReturn = Convert.ToInt32(newShift.ExecuteNonQuery());
                    return keyReturn;
                }
                catch (SqlException se)
                {
                    return -3;
                }
                catch (Exception ex)
                {
                    return -5;
                }
            }


        }

        public int UpdateInsuranceInfo(int empID, string fNameCheck, string lNameCheck, decimal medInsDed, decimal dentInsDed)
        {
            using (SqlConnection dbConnect = new SqlConnection())
            {
                SqlCommand newShift = new SqlCommand();
                try
                {
                    //create connection with database. Specify procedure to use (insert new employee)
                    dbConnect.ConnectionString = scon.ConnectionString;
                    dbConnect.Open();
                    newShift.Connection = dbConnect;
                    newShift.CommandType = CommandType.StoredProcedure;
                    newShift.CommandText = "UpdateInsuranceInfo";
                    newShift.Parameters.Clear();

                    newShift.Parameters.Add("@EmpID", SqlDbType.Int).Value = empID;
                    newShift.Parameters.Add("@FNameCheck", SqlDbType.VarChar).Value = fNameCheck;
                    newShift.Parameters.Add("@LNameCheck", SqlDbType.VarChar).Value = lNameCheck;
                    newShift.Parameters.Add("@MedInsDed", SqlDbType.Money).Value = medInsDed;
                    newShift.Parameters.Add("@DentInsDed", SqlDbType.Money).Value = dentInsDed;

                    int keyReturn = Convert.ToInt32(newShift.ExecuteNonQuery());
                    return keyReturn;
                }
                catch (SqlException se)
                {
                    return -3;
                }
                catch (Exception ex)
                {
                    return -5;
                }
            }
        }

        public int UpdatePayInfo(int empID, string fNameCheck, string lNameCheck, decimal rateOfPay, int empCat)
        {
            using (SqlConnection dbConnect = new SqlConnection())
            {
                SqlCommand newShift = new SqlCommand();
                try
                {
                    //create connection with database. Specify procedure to use (insert new employee)
                    dbConnect.ConnectionString = scon.ConnectionString;
                    dbConnect.Open();
                    newShift.Connection = dbConnect;
                    newShift.CommandType = CommandType.StoredProcedure;
                    newShift.CommandText = "UpdatePayInfo";
                    newShift.Parameters.Clear();

                    newShift.Parameters.Add("@EmpID", SqlDbType.Int).Value = empID;
                    newShift.Parameters.Add("@FNameCheck", SqlDbType.VarChar).Value = fNameCheck;
                    newShift.Parameters.Add("@LNameCheck", SqlDbType.VarChar).Value = lNameCheck;
                    newShift.Parameters.Add("@RateOfPay", SqlDbType.Money).Value = rateOfPay;
                    newShift.Parameters.Add("@EmpCat", SqlDbType.Int).Value = empCat;

                    int keyReturn = Convert.ToInt32(newShift.ExecuteNonQuery());
                    return keyReturn;
                }
                catch (SqlException se)
                {
                    return -3;
                }
                catch (Exception ex)
                {
                    return -5;
                }
            }
        }

        public int UpdateContact(int empID, string fNameCheck, string lNameCheck, string address, string city, string state, string zip, string email, string phone)
        {
            using (SqlConnection dbConnect = new SqlConnection())
            {
                SqlCommand newShift = new SqlCommand();
                try
                {
                    //create connection with database. Specify procedure to use (insert new employee)
                    dbConnect.ConnectionString = scon.ConnectionString;
                    dbConnect.Open();
                    newShift.Connection = dbConnect;
                    newShift.CommandType = CommandType.StoredProcedure;
                    newShift.CommandText = "UpdateContact";
                    newShift.Parameters.Clear();

                    newShift.Parameters.Add("@EmpID", SqlDbType.Int).Value = empID;
                    newShift.Parameters.Add("@FNameCheck", SqlDbType.VarChar).Value = fNameCheck;
                    newShift.Parameters.Add("@LNameCheck", SqlDbType.VarChar).Value = lNameCheck;
                    newShift.Parameters.Add("@Address", SqlDbType.VarChar).Value = address;
                    newShift.Parameters.Add("@City", SqlDbType.VarChar).Value = city;
                    newShift.Parameters.Add("@State", SqlDbType.VarChar).Value = state;
                    newShift.Parameters.Add("@Zip", SqlDbType.VarChar).Value = zip;
                    newShift.Parameters.Add("@Email", SqlDbType.VarChar).Value = email;
                    newShift.Parameters.Add("@Phone", SqlDbType.VarChar).Value = phone;

                    int keyReturn = Convert.ToInt32(newShift.ExecuteNonQuery());
                    return keyReturn;
                }
                catch (SqlException se)
                {
                    return -3;
                }
                catch (Exception ex)
                {
                    return -5;
                }
            }
        }

        public int DeleteTimesheet(int checkNumber)
        {
            using (SqlConnection dbConnect = new SqlConnection())
            {
                SqlCommand newShift = new SqlCommand();
                try
                {
                    //create connection with database. Specify procedure to use (insert new employee)
                    dbConnect.ConnectionString = scon.ConnectionString;
                    dbConnect.Open();
                    newShift.Connection = dbConnect;
                    newShift.CommandType = CommandType.StoredProcedure;
                    newShift.CommandText = "DeleteTimesheet";
                    newShift.Parameters.Clear();

                    newShift.Parameters.Add("@CheckNumber", SqlDbType.Int).Value = checkNumber;

                    int keyReturn = Convert.ToInt32(newShift.ExecuteNonQuery());
                    return keyReturn;
                }
                catch (SqlException se)
                {
                    return -3;
                }
                catch (Exception ex)
                {
                    return -5;
                }
            }
        }

        #endregion
    }
}
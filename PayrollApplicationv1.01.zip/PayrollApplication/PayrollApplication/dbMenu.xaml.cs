﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using PayrollApplication.Windows;

namespace PayrollApplication.Windows
{
    /// <summary>
    /// Interaction logic for dbMenu.xaml
    /// </summary>
    public partial class dbMenu : Window
    {
        public dbMenu()
        {
            InitializeComponent();
        }

        #region buttonEvents
        private void btnInsertEmployee_Click(object sender, RoutedEventArgs e)
        {
            NewEmployeeForm nef = new NewEmployeeForm();
            nef.Show();
            this.Close();
        }

        private void btnInsertShift_Click(object sender, RoutedEventArgs e)
        {
            NewShiftForm nsf = new NewShiftForm();
            nsf.Show();
            this.Close();
        }

        private void btnNewTimesheet_Click(object sender, RoutedEventArgs e)
        {
            NewTimesheetForm ntf = new NewTimesheetForm();
            ntf.Show();
            this.Close();
        }

        private void btnExit_Click(object sender, RoutedEventArgs e)
        {
            System.Windows.Application.Current.Shutdown();
        }

        private void btnBrowseEmployees_Click(object sender, RoutedEventArgs e)
        {
            EmployeeBrowse eb = new EmployeeBrowse();
            eb.Show();
            this.Close();
        }

        private void btnBrowseShifts_Click(object sender, RoutedEventArgs e)
        {
            ShiftBrowse sb = new ShiftBrowse();
            sb.Show();
            this.Close();
        }

        private void btnBrowseTimesheets_Click(object sender, RoutedEventArgs e)
        {
            TimesheetBrowse tb = new TimesheetBrowse();
            tb.Show();
            this.Close();
        }
        private void btnUpdateEmployee_Click(object sender, RoutedEventArgs e)
        {
            EmployeeUpdate eu = new EmployeeUpdate();
            eu.Show();
            this.Close();
        }
        #endregion
    }
}
